const color = ["red", "green", "blue"];

const [a, b, c] = color;

console.log(a ,b ,c)