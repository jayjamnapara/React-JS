const obj1 = { a: 1, b: 2 };  

const obj2 = {...obj1}

console.log(obj2)