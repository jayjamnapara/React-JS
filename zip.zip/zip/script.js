const user = {name:"Alice", age:25, contry:"USA"}

const {name , age, contry} = user

console.log(name,age,contry)